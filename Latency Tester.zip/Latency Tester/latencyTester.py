#Node latency tester v1.2

#Could be improved but works fine for getting an estimate of latency.

#--------------------------------------------------------------------------------------------------------------
try:
    from web3 import Web3
    from web3.middleware import geth_poa_middleware
except:
    print("ERROR: Web3 isn't installed!")
    input("Press ENTER to exit...")
import datetime
import traceback

print("BlockchainTokenSniper Latency Tester v1.2")

blockchainNode = input("Please enter full node URL without quotes or spaces (eg. wss://example_node_url.com): ")

minGetFilterChangesCount = int(input("Please enter min amount of requests to use for getFilterChanges (default is 1000, more = more accurate): "))

minGetTransactionByHashCount = int(input("Please enter min amount of requests to use for getTransactionByHash (default is 1000, more = more accurate): "))

try:
    web3 = Web3(Web3.WebsocketProvider(blockchainNode))

    web3.middleware_onion.inject(geth_poa_middleware, layer=0)

    getFilterChangesTimes = [-1] * minGetFilterChangesCount #using -1 as less than 0, easier to work with
    getFilterChangesTimeIndex = 0
    totalGetFilterChangesCount = 0

    #-----------------------------------------------------------------------------------------------------------------------------------
    print("Node syncing: " + str(web3.eth.syncing))
    print("Node current block: " + str(web3.eth.get_block("pending")['number']))
    print("Measuring getFilterChanges latency...")

    while totalGetFilterChangesCount <= minGetFilterChangesCount:
        try:
            txFilter = web3.eth.filter('pending')
            getFilterChangesCount = 0
            
            timeA = datetime.datetime.now()
            
            for pending in txFilter.get_new_entries():           
                txHash = str(Web3.toHex(pending)) #get hash (simulation)            
                getFilterChangesCount += 1
                totalGetFilterChangesCount += 1

            timeB = datetime.datetime.now()
            
            getFilterChangesTotalTime = timeB - timeA #get time difference 

            if getFilterChangesCount > 0:
                getFilterChangesMsTotal = getFilterChangesTotalTime.microseconds / 1000
                getFilterChangesTimes[getFilterChangesTimeIndex - 1] = getFilterChangesMsTotal / getFilterChangesCount
                print(str(round(((totalGetFilterChangesCount / minGetFilterChangesCount) * 100), 2)) + "% complete...") #give a progress update, may overshoot a bit but not an issue
                getFilterChangesTimeIndex += 1
            else:
                print("Node returned 0 getFilterChanges...")
        except:
            pass#print(traceback.format_exc())
        
    print("Measured getFilterChanges latency.")
    print("Calculating average getFilterChanges latency...")


    try: #remove -1's from array
        while True:
            getFilterChangesTimes.remove(-1)
    except ValueError:
        pass

    getFilterChangesAvgLatencyTotal = 0

    for i in range(0, len(getFilterChangesTimes) - 1):
        getFilterChangesAvgLatencyTotal += getFilterChangesTimes[i]

    getFilterChangesAvgLatency = round((getFilterChangesAvgLatencyTotal / totalGetFilterChangesCount), 5)

    print("Calculated average getFilterChanges latency.")

    #-----------------------------------------------------------------------------------------------------------------------------------

    getTransactionByHashTimes = [-1] * minGetTransactionByHashCount
    getTransactionByHashTimeIndex = 0
    totalGetTransactionByHashCount = 0



    print("Measuring getTransactionByHash latency...")

    while totalGetTransactionByHashCount <= minGetTransactionByHashCount:
        try:
            
            getTransactionByHashCount = 0
            
            timeA = datetime.datetime.now()     
            getTransactionByHash = web3.eth.get_transaction("0x01a5a693ce863bc51da432eb9bd2adc429e82ef451635ad24861bcfc703da1c6") #just a random TX. Any one can be used, shouldn't affect results much                 
            timeB = datetime.datetime.now()
            
            getTransactionByHashTotalTime = timeB - timeA

            getTransactionByHashMsTotal = getTransactionByHashTotalTime.microseconds / 1000
            getTransactionByHashTimes[getTransactionByHashTimeIndex - 1] = getTransactionByHashMsTotal
            
            print(str(round(((totalGetTransactionByHashCount / minGetTransactionByHashCount) * 100), 2)) + "% complete...")

            totalGetTransactionByHashCount += 1
            getTransactionByHashTimeIndex += 1

            
        except:
            pass#print(traceback.format_exc())

        
    print("Measured getTransactionByHash latency.")
    print("Calculating average getTransactionByHash latency...")

    try: #remove -1's from array
        while True:
            getTransactionByHashTimes.remove(-1)
    except ValueError:
        pass


    getTransactionByHashAvgLatencyTotal = 0

    for i in range(0, len(getTransactionByHashTimes) - 1):
        getTransactionByHashAvgLatencyTotal += getTransactionByHashTimes[i]

    getTransactionByHashAvgLatency = round((getTransactionByHashAvgLatencyTotal / totalGetTransactionByHashCount), 5)

    print("Calculated average getTransactionByHash latency.")

    #-------------------------------------------------------------------------------------------------------------------------------------------------------------

    print("")
    print("Generating report...")
    print("")
    print("--------------------------------------------------------------REPORT--------------------------------------------------------------")
    print("")
    print("> Using node URL: " + blockchainNode)
    print("")
    print("> getFilterChanges: " + str(getFilterChangesAvgLatency) + "ms average delay.")
    print("> getFilterChanges: " + str(totalGetFilterChangesCount) + " requests used.")
    print("")
    print("> getTransactionByHash: " + str(getTransactionByHashAvgLatency) + "ms average delay.")
    print("> getTransactionByHash: " + str(totalGetTransactionByHashCount) + " requests used.")
    print("")

    print("> Analysis: ")
    print("")
    print("> Assuming max of 300 TX's per block (around 100 per sec):")
    print("")
    print("> getFilterChanges latency target: < 2ms")
    if getFilterChangesAvgLatency < 2:
        print("> getFilterChanges seems to be fast enough.")
    else:
        print("> getFilterChanges seems too slow. You may miss the addLiquidity TX when using mempool sniping (option 2).")

    print("")

    print("> getTransactionByHash latency target: < 10ms")
    if getTransactionByHashAvgLatency < 10:
        print("> getTransactionByHash seems to be fast enough.")
    else:
        print("> getTransactionByHash seems too slow. You may miss the addLiquidity TX when using mempool sniping (option 2).")

        
    print("----------------------------------------------------------------------------------------------------------------------------------")
    print("")
    input("Press enter to exit...")
except:
    print("Uh-oh, something went wrong: " + traceback.format_exc())
    input("Press ENTER to exit...")



    

