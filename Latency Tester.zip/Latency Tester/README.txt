Before running, make sure you've installed Python on your computer.

You will have to install the web3 module to run the latency tester script:

- In command prompt, try 'pip3 install web3'
- If that doesn't work, try 'pip install web3' or 'py -m pip install web3'

